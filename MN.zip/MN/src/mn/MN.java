
package mn;

import java.util.Scanner;

public class MN {

    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        System.out.println("digite m");
        int m = sc.nextInt();
        System.out.println("digite n");
        int n = sc.nextInt();
        int suma = Multiplos7(m) + Multiplos9(n);
        System.out.println("la suma de los primeros " + m + " multiplos de 7, mas los primeros " + n + " multiplos de 9 es: " + suma);
    }

    public static int Multiplos7(int m) {
        int suma = 0;
        for (int i = 1; i <= m; i++) {
            suma += 7 * i;
        }
        return suma;
    }

    public static int Multiplos9(int n) {
        int suma = 0;
        for (int i = 1; i <= n; i++) {
            suma += 9 * i;
        }
        return suma;
        
    }
    
}
