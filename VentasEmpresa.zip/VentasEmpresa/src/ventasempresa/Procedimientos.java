package ventasempresa;

import java.util.Scanner;

public class Procedimientos {

    Scanner entrada = new Scanner(System.in);

    String dias[] = {"Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"};
    int ventaMatriz[][] = new int[6][7];

    public int[][] getVentaMatriz() {
        return ventaMatriz;
    }

    public int[][] LlenarMatriz() {

        //Llenar la Matriz completa
        for (int i = 0; i < ventaMatriz.length; i++) {
            for (int j = 0; j < ventaMatriz[i].length; j++) {
                System.out.print("Digite el valor de la venta de la sede " + (i + 1) + " del dia " + dias[j] + ": ");
                ventaMatriz[i][j] = entrada.nextInt();
            }
        }

        // Imprimir los nombres de los días
        System.out.print("\t");
        for (String dia : dias) {
            System.out.print(dia + "\t");
        }
        System.out.println();

        // Mostrar la matriz
        for (int i = 0; i < ventaMatriz.length; i++) {
            System.out.print("sede " + (i + 1) + ":\t");
            for (int j = 0; j < ventaMatriz[i].length; j++) {
                System.out.print(ventaMatriz[i][j] + "\t");
            }
            System.out.println();
        }
        return ventaMatriz;
    }
}
