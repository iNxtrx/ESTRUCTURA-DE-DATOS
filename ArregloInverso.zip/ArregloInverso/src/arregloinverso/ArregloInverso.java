
package arregloinverso;

import javax.swing.JOptionPane;

public class ArregloInverso {

    public static void main(String[] args) 
    {
        int[] numeros = new int[100];

        
        for(int i=0; i<numeros.length; i++)
        {
            numeros[i]=i+1;
        }
        
        for(int i=numeros.length-1; i>=0; i--)
        {
            
            
            if (numeros[i]%10==0)
            {
                JOptionPane.showMessageDialog(null, "El conteo va en " + numeros[i]);
            }
            
            if (numeros[i]==1)
            {
                JOptionPane.showMessageDialog(null, "El conteo va en " + i + " y ha llegado a su fin.");
            }
            System.out.println(numeros[i]);
        }
    }
    
}
