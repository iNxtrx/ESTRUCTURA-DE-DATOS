package pq;

import java.util.Scanner;

public class PQ {

    public static void main(String[] args) {
        int p , q;
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese P");
        p=sc.nextInt();
        System.out.println("Ingrese Q");
        q=sc.nextInt(); 
        
        for (int i=p; i<=q; i++)
        {
            if (i%2==0)
            {
                System.out.println(i);
            }
        }
    }
    
}
