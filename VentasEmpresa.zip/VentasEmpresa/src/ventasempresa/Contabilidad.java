package ventasempresa;

public class Contabilidad extends Procedimientos {

    private int suma; //Variable de suma total
    int semana = ventaMatriz.length;
    int dSemana = ventaMatriz[0].length;
    double[] promediosSemanas = new double[semana];
    double[] aumentoPorcentaje = new double[semana];

    public void PromedioMatriz(int[][] ventaMatriz) {

        //Recorrer matriz de VentaMatriz
        for (int i = 0; i < semana; i++) {
            int sumaSemana = 0; //Variable de suma a la semana
            for (int j = 0; j < dSemana; j++) {
                sumaSemana += ventaMatriz[i][j]; //Suma de la semana sumando lo de la matriz
            }

            //Calcular promedio de ventas por cada sede a la semana
            double promedioSemana = (double) sumaSemana / dSemana;
            System.out.println("Promedio de ventas en la sede " + (i + 1) + ": " + promedioSemana);

            suma += sumaSemana;

            promediosSemanas[i] = promedioSemana;
        }

        double promedioTotal = (double) suma / (semana * dSemana);
        System.out.println("Promedio total de ventas por sede a la semana: " + promedioTotal + "\n");

        //Mostrar valores mayores al promedio de la sede por ventas semanales
        for (int i = 0; i < semana; i++) {
            System.out.print("\nValores por encima del promedio en la sede " + (i + 1) + ": ");
            for (int j = 0; j < dSemana; j++) {
                if (ventaMatriz[i][j] > promediosSemanas[i]) {
                    System.out.print("\nDia " + (j + 1) + ": " + ventaMatriz[i][j]);
                }
            }

        }

    }

    public void AumentoPorcentaje(int[][] ventaMatriz) {
        for (int i = 0; i < semana; i++) {
            System.out.print("\nValores por debajo del promedio en la sede " + (i + 1) + " con el 15% agregado: ");
            for (int j = 0; j < dSemana; j++) {
                if (ventaMatriz[i][j] < promediosSemanas[i]) {
                    System.out.print("\nDia " + (j + 1) + ": " + ventaMatriz[i][j]);
                    
                    aumentoPorcentaje[i] = ventaMatriz[i][j];

                    double aumento = (double) aumentoPorcentaje[i] * 0.15;
                    double total = (double) aumento + aumentoPorcentaje[i];
                    
                    System.out.print("\n+15%: " + total);

                }
            }

        }
    }
}
