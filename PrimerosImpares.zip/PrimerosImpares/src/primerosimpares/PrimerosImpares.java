
package primerosimpares;

import java.util.Scanner;

public class PrimerosImpares {

    public static void main(String[] args) {
       
        int z=0;
        int contador=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("ingrese el numero");
        z=sc.nextInt();
        for (int i=0; i<z; i++)
        {
            contador+=3;
            System.out.println(contador);
        }
        
    }
    
}
