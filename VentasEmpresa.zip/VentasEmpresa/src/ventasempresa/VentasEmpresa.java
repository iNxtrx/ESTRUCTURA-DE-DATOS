package ventasempresa;

import java.util.Scanner;

public class VentasEmpresa {

    Scanner entrada = new Scanner(System.in);
    Contabilidad cont = new Contabilidad();
    Procedimientos proc = new Procedimientos();

    public void MenuVentasEmpresa() {
        do {
            System.out.println();
            System.out.print("Sistema de Ventas totales de la Empresa\n");
            System.out.print("1. Digitar ventas de la empresa por sedes\n");
            System.out.print("2. Promedio de ventas empresa y por sedes a la semana con comparativas\n");
            System.out.print("3. Aumento 15%\n");
            System.out.print("4. SALIR\n");
            System.out.print("Digite la opcion a realizar\n");

            int txt = entrada.nextInt();
            entrada.nextLine();

            switch (txt) {
                case 1: {
                    proc.LlenarMatriz();
                    break;
                }
                case 2: {
                    cont.PromedioMatriz(proc.getVentaMatriz());
                    break;
                }
                case 3: {
                    cont.AumentoPorcentaje(proc.getVentaMatriz());
                    break;
                }
                case 4: {
                    System.out.println("-------------- Ventas SAS ------------------");
                    return;

                }
                default: {
                    System.out.println("Opcion incorrecta, digite del 1-4");
                    break;
                }
            }

        } while (true);
    }

    public static void main(String[] args) {
        VentasEmpresa ventas = new VentasEmpresa();
        ventas.MenuVentasEmpresa();
    }

}
