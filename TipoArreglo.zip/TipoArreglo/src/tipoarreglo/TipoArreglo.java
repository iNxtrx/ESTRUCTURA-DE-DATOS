package tipoarreglo;

public class TipoArreglo {

    public static <T> void printArray(T[] array) {
        for (T element : array) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {

        Integer[] intArray = {1, 2, 3};
        String[] strArray = {"hola", "profe", "lo", "quiero", "mucho"};
        Double[] doubleArray = {0.9, 6.9, 3.0, 4.4};

        System.out.println("Arreglo con entero:");
        printArray(intArray);
        System.out.println("*************************************");
        System.out.println("Arreglo con String:");
        printArray(strArray);
        System.out.println("*************************************");
        System.out.println("Arreglo con double:");
        printArray(doubleArray);
    }
}
